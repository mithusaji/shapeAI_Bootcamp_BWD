
<!DOCTYPE html>
<html lang="en">
  <head>
      <title>JSX</title>
          <link rel="stylesheet" href="styles.css" />
            </head>

              <body>
                  <div id="root"></div>
                      <script src="../src/index.js" type="text/JSX"></script>
                        </body>
                        </html